DAYONE / DEVS IN HOODIES — COMPLETE ASSET LIBRARY
Version: 1.0 | Format: WebP | Prepared: 2026-10-30

WHAT'S INCLUDED
01_Brand_Reference/
  - Brand visual rules card
  - Supplied poster and generated roadmap/asset-board references
02_Social_Assets/
  - Reusable social cards: announcement, follow, Telegram, creator campaign, story
03_Roadmap_Assets/
  - Five separate milestone cards and one overview
04_UI_Icons/
  - Twelve individual generic UI icons and an icon sheet
05_Backgrounds/
  - Four lightweight procedural backgrounds
06_Production_Notes/
  - This manifest and QC checklist

LOCKED BRAND RULES
- Brand: $DayOne / Devs In Hoodies
- Campaign language: THE RESURGENCE
- Mascot reference: brown beaver, cream muzzle, black sunglasses, yellow hard hat, black hoodie.
- NO RED TIE.
- Preserve original mascot art whenever exact mascot consistency matters.
- Palette: near-black, gold, white; cyan/orange/green only as secondary accents.

IMPORTANT QUALITY / INTEGRITY NOTES
1. This package is a polished working asset library, not a claim that every source-sheet crop is an individually isolated production-ready mascot.
2. Reference sheets are retained for visual direction only. The mascot poses embedded in those sheets are not transparent cut-outs.
3. QR images in generated reference sheets are NOT production-safe. Create a real QR from the verified destination before publishing.
4. The contract address printed in generated reference art may be inaccurate/garbled. Never publish it from generated art; copy the verified address from the official source and test it.
5. Roadmap cards follow the previously approved brief: $10K Creator Campaign, $25K DayOne Arena, $50K Rocket Standby, $100K Community Rise, $1M Reach the Moon. Do not use the older generated-sheet figures ($100K/$250K/$500K/$1M/$5M) as canonical.
6. Social handle in the remembered design brief: @DayOne_DIH; Telegram: @DAYONESOLANA / DayOneSolana. Verify exact live handles and destination links before publication.
7. Poster brief for The Resurgence: 48 Hours, 125 Winners, 25% Creator Fee, $10,000 market-cap target, small but legible “RETWEET THIS POST”. This is a campaign poster spec; don't silently apply it to all social assets.
8. Generic UI icons are newly drawn symbols, not official X/Telegram logos. Use official platform marks only when permitted and necessary.

QC CHECKLIST BEFORE PUBLICATION
[ ] Confirm current official account handles and Telegram URL.
[ ] Generate and scan a real QR code to the confirmed destination.
[ ] Verify any contract address by copy/paste and compare character-for-character.
[ ] Review all in-image text at phone size.
[ ] Replace generic placeholder CTA links with real destinations.
[ ] Use the original mascot reference art to preserve exact face, glasses, hard hat, hoodie, and silhouette.
[ ] Keep editable source designs in Canva or SVG if text/layout will need future changes.

FILES ARE WEBP FOR LIGHTWEIGHT DELIVERY. They are not all transparent PNG cut-outs; individual icon/background assets are opaque or transparent as noted by their visual composition.
