DAYONE — THE RESURGENCE
ROADMAP WEBP ASSET PACK

Included:
- 00_master_asset_sheet.webp — complete generated visual inventory sheet
- 01–16 — cropped WebP panels for the hero banner, logo banner, social banner,
  ecosystem/checklist cards, roadmap milestones, badges, UI icons, buttons,
  signs, decorations, mascot poses, backgrounds, and reference info cards.

Important production notes:
1. These are WebP crops from a single composed asset sheet. Most category files
   still contain multiple items and/or the original panel framing. They are useful
   as design references and quick mockup materials, but are NOT individual
   transparent production assets yet.
2. The QR and contract-card crops are visual references only. Do not use the
   embedded QR code as a live invite link without scanning and verifying it.
3. Verify all text and the contract address manually before publishing. Image
   generation can introduce text/QR inaccuracies.
4. To make production-ready assets, each mascot, icon, logo, button and decoration
   should be isolated into its own file, cleaned, and exported with transparent
   backgrounds where appropriate.
5. Keep the original high-resolution/vector masters for logos and text where
   possible. WebP is best for web delivery, while SVG is preferable for crisp
   logos and icons.

Suggested filenames for future isolated assets:
mascot_idle.webp, mascot_wave.webp, mascot_flag.webp, mascot_building.webp,
mascot_gaming.webp, logo_dayone.webp, logo_resurgence.webp, icon_rocket.webp,
icon_community.webp, icon_gamepad.webp, icon_crown.webp, button_join_telegram.webp,
background_city_night.webp, background_blue_islands.webp, roadmap_100k.webp,
roadmap_250k.webp, roadmap_500k.webp, roadmap_1m.webp, roadmap_5m.webp.
