DIH / DAYONE COMPLETE ASSET BUNDLE

Contents:
- DayOne_Roadmap_WebP_Assets/: roadmap and UI asset set
- DayOne_Complete_Asset_Library/: complete existing asset library
- DIH_New_Pixel_Assets/dih_beaver_pixel_static.webp: newly generated static pixel beaver mascot

Note: The new mascot WebP has an RGBA channel. Inspect its edge transparency on the intended dark background before production use. Original asset packs are preserved without modification.
